package com.otb.strawberryroad;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class activity_mobile extends AppCompatActivity {

    private EditText numberText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mobile);

        numberText = findViewById(R.id.editText_number);

        findViewById(R.id.button_save).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                saveMobile();
            }
        });
    }

    private void saveMobile(){
        final String sNumber=numberText.getText().toString().trim();
        if (sNumber.isEmpty()){
            numberText.setError("Task required");
            numberText.requestFocus();
            return;
        }

        class SaveMobile extends AsyncTask<Void,Void,Void>{

            @Override
            protected Void doInBackground(Void... voids) {

                //creating a task
                mobile mobile = new mobile();
                mobile.setNumber(sNumber);
                mobile.setDefault(false);
                mobile.setVerified(false);

                //adding to database
                DatabaseClient.getInstance(getApplicationContext()).getAppDatabase()
                        .mobileDao()
                        .insert(mobile);
                return null;
            }

            @Override
            protected void onPostExecute(Void aVoid) {
                super.onPostExecute(aVoid);
                finish();
                startActivity(new Intent(getApplicationContext(), MainActivity.class));
                Toast.makeText(getApplicationContext(), "Saved", Toast.LENGTH_LONG).show();
            }
        }

        SaveMobile st = new SaveMobile();
        st.execute();

    }

}
