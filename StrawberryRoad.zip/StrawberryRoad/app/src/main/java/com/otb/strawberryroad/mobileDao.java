package com.otb.strawberryroad;

import java.util.List;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

@Dao
public interface mobileDao {

    @Query("SELECT * FROM mobile")
    List<mobile> getAll();

    @Insert
    void insert(mobile mobile);

    @Delete
    void delete(mobile mobile);

    @Update
    void update(mobile mobile);
}
